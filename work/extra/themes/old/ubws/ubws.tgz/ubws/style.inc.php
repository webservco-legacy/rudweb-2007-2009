<?php
/*
./themes/ubws/style.inc.php
14:06 2008-03-11
*/
if(!defined('_RSWEB_PUBFIL')) {require_once '../../lib/404.php';}

echo "\n<STYLE type=\"text/css\">";
echo "\n<!--";
require_once _RSWEB_THEME_DIR . $_SESSION[_RSWEB_PRE.'usr_theme_dir'] . '/styles/default.css';
require_once _RSWEB_THEME_DIR . $_SESSION[_RSWEB_PRE.'usr_theme_dir'] . '/styles/custom.css';
echo "\n-->";
echo "\n</STYLE>";
?>