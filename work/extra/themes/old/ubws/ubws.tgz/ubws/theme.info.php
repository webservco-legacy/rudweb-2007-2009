<?php
/* 
./themes/ubws/theme.info.php
14:52 2008-03-12
*/
if(!defined('_RSWEB_PUBFIL')) {require_once '../../lib/404.php';}

$rsweb_theme_name     = 'UBWS';
$rsweb_theme_version  = '1.0.080312';
$rsweb_theme_author   = 'Radu Maier';
$rsweb_theme_notes    = 'Old Ubws Theme';
?>