<?php
/*
./themes/ubws/headeri.inc.php
09:46 2008-01-21
*/
if(!defined('_RSWEB_PUBFIL')) {require_once '../../lib/404.php';}
?>
<DIV ID="container">
  <DIV CLASS="header">
    <?php restrictedLocalLink('default', _RSWEB_WSTT, 'index.php/rsweb/about', $_SESSION[_RSWEB_PRE.'usr_level'], 0, $rsweb_ln['WinStatOver'], $rsweb_ln['WinStatOut'], "_self"); ?>
  </DIV>
  <DIV ID="footer">
    <?php genCopyright(); ?>
  </DIV>
</DIV>