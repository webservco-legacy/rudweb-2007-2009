<?php
/*
./themes/ubws/footeri.inc.php
09:54 2008-01-21
*/
if(!defined('_RSWEB_PUBFIL')) {require_once '../../lib/404.php';}
?>