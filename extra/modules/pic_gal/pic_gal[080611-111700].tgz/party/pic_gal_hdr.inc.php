<?php
/**
* Simple image gallery include
*
* <I>./party/pic_gal_hdr.inc.php</I>
* <BR>Picture gallery header
* 
* @author Radu Maier <rudisoft@rudisoft.net>
* @copyright Copyright (c) 2007-2008, Radu Maier
* @license http://opensource.org/licenses/gpl-2.0.php
* @version 10:54 2008-06-11
* @access public
* @package RudWEb
* @subpackage Extra
* @since 10:47 2008-06-11
* @todo Integrate in engine
*/


echo '<IMG SRC="'. _RUDWEB_SITE_URL . '/'.$pic_gal_dir.'/pic_gal_hdr.jpg" WIDTH="600" HEIGHT="182" ALT="'. _RUDWEB_WSTT.'" TITLE="'. _RUDWEB_WSTT.'">';
?>