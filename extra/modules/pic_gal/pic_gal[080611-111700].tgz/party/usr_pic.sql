DROP TABLE IF EXISTS mhs_usr_pic;
CREATE TABLE mhs_usr_pic (
  usr_pic_id int(5) unsigned NOT NULL,
  usr_pic_fn varchar(255) NOT NULL,
  usr_pic_ds varchar(255) NOT NULL,
  usr_pic_crd date NOT NULL,
  usr_pic_crt time NOT NULL,
  usr_pic_cru int(5) unsigned NOT NULL,
  usr_pic_mdd date NOT NULL,
  usr_pic_mdt time NOT NULL,
  usr_pic_mdu int(5) unsigned NOT NULL,
  PRIMARY KEY (usr_pic_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;