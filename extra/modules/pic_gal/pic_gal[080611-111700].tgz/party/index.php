<?php
/**
* Simple image gallery index
*
* <I>./party/index.inc.php</I>
* <BR>Redirects to gallery page
* 
* @author Radu Maier <rudisoft@rudisoft.net>
* @copyright Copyright (c) 2007-2008, Radu Maier
* @license http://opensource.org/licenses/gpl-2.0.php
* @version 10:52 2008-06-11
* @access public
* @package RudWEb
* @subpackage Extra
* @since 10:47 2008-06-11
* @todo Integrate in engine
*/
define("_RUDWEB_PUBFIL", TRUE);
require_once './../inc/config.inc.php';
$pic_gal_location = _RUDWEB_SITE_URL . _RUDWEB_INDEX_PHP . "page/party";
header("Location: $pic_gal_location");
?>