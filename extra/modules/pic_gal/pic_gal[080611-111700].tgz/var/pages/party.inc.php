<?php
/**
* Simple image gallery
*
* <I>./var/pages/party.inc.php</I>
* <BR>Separate module for simple image gallery with administration
* 
* @author Radu Maier <rudisoft@rudisoft.net>
* @copyright Copyright (c) 2007-2008, Radu Maier
* @license http://opensource.org/licenses/gpl-2.0.php
* @version 10:18 2008-06-11
* @access public
* @package RudWEb
* @subpackage Extra
* @since 16:51 2008-06-10
* @todo Integrate in engine
*/

/**
* Authorized access only
*/
if(!defined('_RUDWEB_PUBFIL')) {require_once './../../lib/404.php';}

// start editing
$pic_gal_dir = 'party';
$gal_pic_max_size = '120';
$pic_gal_tt = 'Party';
$req_usr_level = 2;
$allowed_file_types = array("image/jpeg", "image/pjpeg", "image/png", "image/x-png", "image/gif");
// stop editing

require_once _RUDWEB_SITE_DIR . '/' . $pic_gal_dir . '/pic_gal_hdr.inc.php';

echo '<DIV CLASS="title">';
echo $pic_gal_tt;
echo '</DIV>';
echo '<DIV CLASS="text">';

if (isset($_GET['admin'])) {
  
  if ($_SESSION[_RUDWEB_PRE.'usr_level'] >= $req_usr_level) {
    $picaction = rudweb_filter_input($_GET['admin']);
    switch ($picaction) {
      case 'upload' : {
      // upload
      echo '<DIV CLASS="subtitle">Upload pictures</DIV>';
      if(isset($_POST['usr_pic_upload']) && isset($_FILES['usr_pic_file'])) {
        $action_date  = date("Y-m-d");
        $action_time  = date("H:i:s");
        foreach ($_FILES['usr_pic_file']['error'] as $pic_num => $error) {
          $file_name[$pic_num]  = $_FILES['usr_pic_file']['name'][$pic_num];
          $file_type[$pic_num]  = $_FILES['usr_pic_file']['type'][$pic_num];
          $file_temp[$pic_num]  = $_FILES['usr_pic_file']['tmp_name'][$pic_num];
          $file_error[$pic_num] = $_FILES['usr_pic_file']['error'][$pic_num];
          $file_size[$pic_num]  = $_FILES['usr_pic_file']['size'][$pic_num];
          
          if ($file_error[$pic_num] == '0' && !in_array($file_type[$pic_num], $allowed_file_types)) {/* NOT A PICTURE */$err = '1';}
          else if ($file_error[$pic_num] == '4') {/* NO FILE UPLOADED */ $err = '2';}
          else if ($file_error[$pic_num] == '3') {/* PARTIAL UPLOAD */ $err = '3';}
          else if ($file_error[$pic_num] == '0' && !is_uploaded_file($file_temp[$pic_num])) {/*NOT SENT BY FORM*/ $err = '4';}
          else if ($file_error[$pic_num] == '0') {/* OK */ $err = '0';}
          if ($err == 0) {
            $upload_dir[$pic_num] = _RUDWEB_SITE_DIR . ''.$pic_gal_dir.'/pics/';
            $new_file_name[$pic_num] = ''.$pic_gal_dir.'-' . time() . '-' . $pic_num . '-' . basename($file_name[$pic_num]);
            $new_file_name[$pic_num] = eregi_replace(' ', '_', $new_file_name[$pic_num]);
            $upload_path[$pic_num] = $upload_dir[$pic_num] . $new_file_name[$pic_num];
            if($file_error[$pic_num] == 0) {
              if (move_uploaded_file($file_temp[$pic_num], $upload_path[$pic_num])) {
                $usr_pic_ds[$pic_num] = '';
                if(isset($_POST['usr_pic_ds'][$pic_num]) && rudweb_filter_input($_POST['usr_pic_ds'][$pic_num]) != '') {$usr_pic_ds[$pic_num] = rudweb_filter_input($_POST['usr_pic_ds'][$pic_num]);}
                $qn = "SELECT MAX(usr_pic_id) FROM "._RUDWEB_PRE."usr_pic";
                $rn = rudweb_qres($rudweb_dbtype, $qn);
                $usr_pic_id[$pic_num]  = rudweb_result($rudweb_dbtype, $rn, 0) + 1;
                
                $qp  = "INSERT INTO "._RUDWEB_PRE."usr_pic (usr_pic_id, usr_pic_fn, usr_pic_ds, usr_pic_crd, usr_pic_crt, usr_pic_cru) VALUES ('".$usr_pic_id[$pic_num]."', '".$new_file_name[$pic_num]."', '".$usr_pic_ds[$pic_num]."', '".$action_date."', '".$action_time."', '".$_SESSION[_RUDWEB_PRE.'usr_id']."')";
                mysql_query($qp) or require _RUDWEB_LIB_DIR . 'myerr.php';
                
                echo '<DIV CLASS="ok">' . 'Upload '.$pic_num.' ok!</DIV>';
              }
            }
            else {'<DIV CLASS="err">' . 'Upload '.$pic_num.' failed!</DIV>';}
          }
          else {
            switch($err) {
              case '1' : {echo '<DIV CLASS="err">Upload '.$pic_num.' failed! Please upload only jpg, png and gif pictures!</DIV>'; break;}
              case '2' : {echo '<DIV CLASS="ok">Upload '.$pic_num.' not sent. No file uploaded.</DIV>'; break;}
              case '3' : {echo '<DIV CLASS="err">Upload '.$pic_num.' failed! Partial Upload!</DIV>'; break;}
              case '4' : {echo '<DIV CLASS="err">Upload '.$pic_num.' failed! File not sent by form!</DIV>'; break;}
              default  : {break;}
            }
          }
        }
        echo '<DIV>';
        restrictedLocalLink('categ', 'Upload pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'/admin/upload', $_SESSION[_RUDWEB_PRE.'usr_level'], $req_usr_level, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '<BR>';
        restrictedLocalLink('categ', 'Modify pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'/admin/admin', $_SESSION[_RUDWEB_PRE.'usr_level'], $req_usr_level, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '<BR>';
        restrictedLocalLink('categ', 'View pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'', $_SESSION[_RUDWEB_PRE.'usr_level'], 0, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '</DIV>';
      }
      else {
        echo '<DIV STYLE="margin: 5px;">Please upload only jpg, png and gif images.<BR>For best user experience image dimensions should not exceed 1024x1024 px.<BR>Filenames must not exceed 230 characters.<BR>Description is optional.</DIV>';
        echo '<FORM ENCTYPE="multipart/form-data" NAME="usr_pic_form" ACTION="" METHOD="post">';
        for($i=1;$i<10;$i++) {
          echo '<DIV STYLE="margin: 5px;">';
          echo 'Picture '.$i.': <INPUT CLASS="imgupload" TYPE="file" NAME="usr_pic_file['.$i.']" SIZE="1">';
          echo ' Description: <INPUT CLASS="forminput" TYPE="text" NAME="usr_pic_ds['.$i.']" SIZE="30" MAXLENGTH="255">';
          echo '</DIV>';
        }
        echo '<INPUT CLASS="formsubmit" TYPE="submit" NAME="usr_pic_upload" VALUE="Upload">';
        echo '</FORM>';
        echo '<DIV>';
        echo '<BR>';
        restrictedLocalLink('categ', 'View all pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'', $_SESSION[_RUDWEB_PRE.'usr_level'], 0, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '</DIV>';
      }
      break;
      }
      case 'admin' : {
      // mod dsc + delete
      echo '<DIV CLASS="subtitle">Modify pictures</DIV>';
      if (isset($_POST['usr_pic_mod'])) {
        $action_date  = date("Y-m-d");
        $action_time  = date("H:i:s");
        if(isset($_POST['usr_pic_del'])) {
          foreach ($_POST['usr_pic_del'] as $usr_pic_id => $dump) {
            $qp = "SELECT usr_pic_fn FROM "._RUDWEB_PRE."usr_pic WHERE usr_pic_id = '".$usr_pic_id."'";
            $rn = rudweb_qres($rudweb_dbtype, $qp);
            $usr_pic_fn[$usr_pic_id]  = rudweb_result($rudweb_dbtype, $rn, 0);
                
            $filepath = _RUDWEB_SITE_DIR . ''.$pic_gal_dir.'/pics/' . $usr_pic_fn[$usr_pic_id];
            if (is_file($filepath)) {unlink($filepath);}
            
            $qp = "DELETE FROM "._RUDWEB_PRE."usr_pic WHERE usr_pic_id = '".$usr_pic_id."'";
            $rp = rudweb_qres($rudweb_dbtype, $qp);
          }
        }
        if(isset($_POST['usr_pic_ds'])) {
          foreach ($_POST['usr_pic_ds'] as $usr_pic_id => $dump) {
            if(rudweb_filter_input($_POST['usr_pic_ds'][$usr_pic_id]) != '') {
              $new_pic_ds = rudweb_filter_input($_POST['usr_pic_ds'][$usr_pic_id]);
              $qp = "UPDATE "._RUDWEB_PRE."usr_pic SET usr_pic_ds = '".$new_pic_ds."', usr_pic_mdd = '".$action_date."', usr_pic_mdt = '".$action_time."', usr_pic_mdu = '".$_SESSION[_RUDWEB_PRE.'usr_id']."' WHERE usr_pic_id = '".$usr_pic_id."'";
              $rp = rudweb_qres($rudweb_dbtype, $qp);
            }
          }
        }
      }
        $qp = "SELECT usr_pic_id, usr_pic_fn, usr_pic_ds FROM "._RUDWEB_PRE."usr_pic ORDER BY usr_pic_crd DESC, usr_pic_crt DESC";
        $rp = rudweb_qres($rudweb_dbtype, $qp);
        $tp = rudweb_qtotal($rudweb_dbtype, $rp);
        
        if($tp != 0) {
          echo '<FORM ENCTYPE="multipart/form-data" NAME="usr_pic_form" ACTION="" METHOD="post">';
          for($k=1;$k<=$tp;$k++) {
            $rw = rudweb_fetch_assoc($rudweb_dbtype, $rp);
            echo '<DIV STYLE="margin: 5px; border-bottom: 1px solid '.$rudweb_skin['Color2'].'; padding: 5px;">';
            $imgsrc[$k] = '<IMG CLASS="op" SRC="'._RUDWEB_LIB_URL .'pic.php?imgfile=' . _RUDWEB_SITE_DIR . ''.$pic_gal_dir.'/pics/' .$rw['usr_pic_fn'] . '&amp;max_size='.$gal_pic_max_size.'" TITLE="'.$rw['usr_pic_ds'].'" ALT="'.$rw['usr_pic_ds'].'" onMouseOver="bevisible(this,0)" onMouseOut="bevisible(this,1)">';
            echo $imgsrc[$k];
            echo ' Description: <INPUT CLASS="forminput" TYPE="text" NAME="usr_pic_ds['.$rw['usr_pic_id'].']" SIZE="30" MAXLENGTH="255" VALUE="'.$rw['usr_pic_ds'].'">';
            echo 'Delete: <INPUT CLASS="forminput" TYPE="checkbox" NAME="usr_pic_del['.$rw['usr_pic_id'].']">';
            echo '</DIV>';
          }
          echo '<INPUT CLASS="formsubmit" TYPE="submit" NAME="usr_pic_mod" VALUE="Modify">';
          echo '</FORM>'; 
        }
        else {echo '<DIV CLASS="err">' . 'No pictures found' . '</DIV>';}
        echo '<DIV CLASS="usr_pic_lnk">';
        restrictedLocalLink('categ', 'Upload pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'/admin/upload', $_SESSION[_RUDWEB_PRE.'usr_level'], $req_usr_level, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '<BR>';
        restrictedLocalLink('categ', 'View all pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'', $_SESSION[_RUDWEB_PRE.'usr_level'], 0, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
        echo '<BR>';
        echo '</DIV>';
      break;
      }
      default : {break;}
    }
  }
  else {echo '<DIV CLASS="err">' . $rudweb_ln['err']['1'] . '</DIV>';}

}
else {
  $qp1 = "SELECT usr_pic_id, usr_pic_fn, usr_pic_ds FROM "._RUDWEB_PRE."usr_pic ORDER BY usr_pic_crd DESC, usr_pic_crt DESC";
  $rp = rudweb_qres($rudweb_dbtype, $qp1);
  $tp = rudweb_qtotal($rudweb_dbtype, $rp);

  if($tp != 0) {
    for($j=1;$j<=$tp;$j++) {
      $rw = rudweb_fetch_assoc($rudweb_dbtype, $rp);
      $usr_pic_dsc[$j] = 'picture ' . $j;
      if($rw['usr_pic_ds'] != '') {$usr_pic_dsc[$j] = $rw['usr_pic_ds'];}
      echo '<DIV CLASS="usr_pic_div">';
      $imgsrc[$j] = '<IMG CLASS="op" SRC="'._RUDWEB_LIB_URL .'pic.php?imgfile=' . _RUDWEB_SITE_DIR . ''.$pic_gal_dir.'/pics/' .$rw['usr_pic_fn'] . '&amp;max_size='.$gal_pic_max_size.'" TITLE="'.$rw['usr_pic_ds'].'" ALT="'.$rw['usr_pic_ds'].'" onMouseOver="bevisible(this,0)" onMouseOut="bevisible(this,1)">';
      $imgurl[$j] = _RUDWEB_SITE_URL . ''.$pic_gal_dir.'/pics/' .$rw['usr_pic_fn'];
      echo '<DIV STYLE="height: '.$gal_pic_max_size.'px;">';
      echo '<A CLASS="default" rel="lightbox[\''.$pic_gal_dir.'\']" HREF="'.$imgurl[$j].'" TITLE="'.$rw['usr_pic_ds'].'">';
      echo $imgsrc[$j];
      echo "</A>";
      echo '</DIV>';
      echo '<BR>';
      echo $usr_pic_dsc[$j];
      echo '</DIV>';
    }
  }
  else {echo '<DIV CLASS="err">' . 'No pictures found' . '</DIV>';}
  if($_SESSION[_RUDWEB_PRE.'usr_level'] >= $req_usr_level) {
    echo '<DIV CLASS="usr_pic_lnk">';
    restrictedLocalLink('categ', 'Upload pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'/admin/upload', $_SESSION[_RUDWEB_PRE.'usr_level'], $req_usr_level, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
    echo '<BR>';
    restrictedLocalLink('categ', 'Modify pictures', _RUDWEB_INDEX_PHP . 'page/'.$pic_gal_dir.'/admin/admin', $_SESSION[_RUDWEB_PRE.'usr_level'], $req_usr_level, $rudweb_ln['WinStatOver'], $rudweb_ln['WinStatOut'], '_self');
    echo '<BR>';
    echo '</DIV>';
  }
}

echo '</DIV>';
?>